# WIFI Scan Example

Simple WIFI scan
